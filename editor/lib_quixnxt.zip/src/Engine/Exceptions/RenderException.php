<?php

namespace QuixNxt\Engine\Exceptions;

use RuntimeException;

class RenderException extends RuntimeException
{

}
