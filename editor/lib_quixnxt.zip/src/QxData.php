<?php

namespace QuixNxt;

use QuixNxt\Engine\Foundation\QuixData;

class QxData extends QuixData {

}
