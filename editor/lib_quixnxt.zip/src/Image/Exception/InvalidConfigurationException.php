<?php

namespace QuixNxt\Image\Exception;

class InvalidConfigurationException extends \Exception
{
}
